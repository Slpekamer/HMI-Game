#!/usr/bin/env bash
set -uo pipefail
ROOT=/workspace/scratch/80f5bc988ef7/HMI-vfx-birth-native-r1
source /workspace/scratch/80f5bc988ef7/godot-toolchain-verification/env.sh
for variant in old fixed; do
 isolation=$(mktemp -d /tmp/hmi-birth-native-XXXXXX)
 XDG_DATA_HOME="$isolation/data" XDG_CONFIG_HOME="$isolation/config" "$GODOT_NET" --audio-driver Dummy --path "$ROOT/$variant" -- --native-birth > "$ROOT/$variant/native.log" 2>&1
 result=$?
 echo "$variant native_exit=$result"
 if [ "$result" -ne 0 ]; then exit "$result"; fi
done
python3 "$ROOT/verify-native-pixels.py"

from pathlib import Path
from PIL import Image, ImageChops
import json,hashlib
root=Path(__file__).resolve().parent
rows=[]
for kind in ('Melee','Ray'):
 images={}
 for variant in ('old','fixed'):
  for stage in ('empty','birth-first-draw','next-expired'):
   with Image.open(root/variant/'evidence'/f'{kind}-{stage}.png') as im:images[variant,stage]=im.convert('RGB').copy()
 baseline=images['old','empty']
 for variant in ('old','fixed'):
  assert images[variant,'empty'].size==baseline.size
  assert ImageChops.difference(images[variant,'empty'],baseline).getbbox() is None,'A/B empty scene differs'
  assert ImageChops.difference(images[variant,'next-expired'],baseline).getbbox() is None,'cue did not disappear by next render'
  box=ImageChops.difference(images[variant,'birth-first-draw'],baseline).getbbox()
  assert (box is None)==(variant=='old'),'actual birth-render pixels do not support expected red/green'
  rows.append(dict(kind=kind,variant=variant,first_draw_changed_bbox=box,width=baseline.width,height=baseline.height))
a=(root/'old/evidence/authority-trace.json').read_bytes();b=(root/'fixed/evidence/authority-trace.json').read_bytes();assert a==b,'authority traces changed'
result=dict(pixel_cases=rows,authority_sha256=hashlib.sha256(a).hexdigest(),note='Controlled replay of genuine Core events, no Core steps during capture; original tint alpha0 limitation not tested away.')
(root/'native-pixel-proof.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

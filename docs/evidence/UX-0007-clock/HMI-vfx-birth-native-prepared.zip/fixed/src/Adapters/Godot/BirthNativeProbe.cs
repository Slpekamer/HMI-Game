using Godot;
using Hmi.Core;
using Hmi.GodotAdapter;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
public partial class BirthNativeProbe:Node3D
{
 Task task;bool ended;int checks;bool native;string output;
 readonly List<object> rows=new();
 void Check(bool c,string r){checks++;if(!c)throw new Exception(r);}
 public override void _Ready(){task=Run();}
 public override void _Process(double d){if(ended||task==null||!task.IsCompleted)return;ended=true;if(task.IsFaulted){GD.PushError(task.Exception.ToString());GetTree().Quit(1);return;}System.IO.File.WriteAllText(output+"/result.json",JsonSerializer.Serialize(new{checks,native,cases=rows},new JsonSerializerOptions{WriteIndented=true}));GD.Print($"BIRTH_NATIVE_COMPLETE checks={checks} native={native}");GetTree().Quit();}
 async Task Capture(string name){await ToSignal(RenderingServer.Singleton,RenderingServer.SignalName.FramePostDraw);using var image=GetViewport().GetTexture().GetImage();Check(image.SavePng(output+"/"+name+".png")==Error.Ok,"actual framebuffer capture");}
 async Task Run(){
  native=Array.Exists(OS.GetCmdlineUserArgs(),s=>s=="--native-birth");output=ProjectSettings.GlobalizePath("res://evidence");System.IO.Directory.CreateDirectory(output);
  var content=JsonSerializer.Deserialize<GameContent>(FileAccess.GetFileAsString("res://content/gameplay.json"),new JsonSerializerOptions{PropertyNameCaseInsensitive=true});
  var sim=new GameSimulation(content,new SimulationLimits());var twin=new GameSimulation(content,new SimulationLimits());sim.StartRun("crit",1030);twin.StartRun("crit",1030);GameEvent? melee=null,ray=null;var trace=new List<object>();
  for(int i=0;i<900&&(!melee.HasValue||!ray.HasValue);i++){sim.Step();twin.Step();sim.TryGetEntity(sim.PlayerId,out var p);twin.TryGetEntity(twin.PlayerId,out var q);Check(sim.Tick==twin.Tick&&sim.Coins==twin.Coins&&sim.EventCount==twin.EventCount&&p.Health==q.Health&&p.Position.Equals(q.Position),"authority twin parity");
   for(int j=0;j<sim.EventCount;j++){var e=sim.GetEvent(j);var z=twin.GetEvent(j);Check(e.Kind==z.Kind&&e.Mechanism==z.Mechanism&&e.From.Equals(z.From)&&e.To.Equals(z.To)&&e.Value==z.Value,"real event parity");trace.Add(new{tick=sim.Tick,index=j,kind=e.Kind.ToString(),mechanism=e.Mechanism.ToString(),fromX=e.From.X,fromY=e.From.Y,toX=e.To.X,toY=e.To.Y,value=e.Value,hp=p.Health,coins=sim.Coins});if(e.Kind==EventKind.Melee&&e.Mechanism==FeedbackMechanism.BasicMelee&&!melee.HasValue)melee=e;if(e.Kind==EventKind.Ray&&e.Mechanism==FeedbackMechanism.Ricochet&&!ray.HasValue)ray=e;}}
  Check(melee.HasValue&&ray.HasValue,"actual Core emitted both attacks");System.IO.File.WriteAllText(output+"/authority-trace.json",JsonSerializer.Serialize(trace));
  if(!native)return;
  Check(DisplayServer.GetName()!="headless"&&!string.IsNullOrEmpty(RenderingServer.GetVideoAdapterName()),"actual non-Dummy renderer required");
  GD.Print("BIRTH_RENDERER "+RenderingServer.GetVideoAdapterName()+" display="+DisplayServer.GetName());
  var a=melee.Value;var b=ray.Value;var center=new Vector3((a.From.X+a.To.X+b.From.X+b.To.X)/4,0,(a.From.Y+a.To.Y+b.From.Y+b.To.Y)/4);
  var world=new Node3D();AddChild(world);var cam=new Camera3D{Projection=Camera3D.ProjectionType.Orthogonal,Size=16.8f,Position=center+new Vector3(12,22,18),Current=true};world.AddChild(cam);cam.LookAt(center,Vector3.Up);
  using(var mesh=new BoxMesh{Size=new Vector3(80,.3f,80)})using(var mat=new StandardMaterial3D{AlbedoColor=new Color(.89f,.81f,.67f),ShadingMode=BaseMaterial3D.ShadingModeEnum.Unshaded})world.AddChild(new MeshInstance3D{Mesh=mesh,MaterialOverride=mat,Position=new Vector3(0,-.15f,0)});
  var feedback=new CombatFeedbackVisuals();AddChild(feedback);feedback.Initialize(512,cam,world);
  foreach(var e in new[]{a,b}){
   feedback.Reset();await Capture(e.Kind+"-empty");
   feedback.BeginFrame(e.RunToken,e.Wave,false,true);Check(feedback.Consume(e,0,e.Tick,sim.PlayerId),"same unchanged real event accepted");feedback.Advance(.25f,false);
   int birth=feedback.ActiveBodyCount;await Capture(e.Kind+"-birth-first-draw");
   feedback.BeginFrame(e.RunToken,e.Wave,false,true);feedback.Advance(.25f,false);Check(feedback.ActiveBodyCount==0,"older cue expires next render without new event");await Capture(e.Kind+"-next-expired");
   rows.Add(new{kind=e.Kind.ToString(),delta=.25f,birthActive=birth,nextActive=feedback.ActiveBodyCount,fromX=e.From.X,fromY=e.From.Y,toX=e.To.X,toY=e.To.Y,coreTick=sim.Tick,coreAdvancedDuringRender=false,cameraSize=cam.Size});
  }
  feedback.QueueFree();await ToSignal(GetTree(),SceneTree.SignalName.ProcessFrame);world.QueueFree();await ToSignal(GetTree(),SceneTree.SignalName.ProcessFrame);
 }
}

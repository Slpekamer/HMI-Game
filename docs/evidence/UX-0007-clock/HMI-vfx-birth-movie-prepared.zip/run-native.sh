#!/usr/bin/env bash
set -uo pipefail
ROOT=/workspace/scratch/80f5bc988ef7/HMI-vfx-birth-movie-r1
source /workspace/scratch/80f5bc988ef7/godot-toolchain-verification/env.sh
for variant in old fixed; do
 mkdir -p "$ROOT/$variant/evidence"
 isolation=$(mktemp -d /tmp/hmi-birth-movie-XXXXXX)
 XDG_DATA_HOME="$isolation/data" XDG_CONFIG_HOME="$isolation/config" "$GODOT_NET" --audio-driver Dummy --fixed-fps 4 --path "$ROOT/$variant" --write-movie "$ROOT/$variant/evidence/movie.avi" > "$ROOT/$variant/native.log" 2>&1
 result=$?; echo "$variant native_exit=$result"; if [ "$result" -ne 0 ]; then exit "$result"; fi
done
cmp "$ROOT/old/evidence/authority-trace.json" "$ROOT/fixed/evidence/authority-trace.json" && cmp "$ROOT/old/evidence/render-authority.tsv" "$ROOT/fixed/evidence/render-authority.tsv"

using Godot;
using Hmi.Core;
using Hmi.GodotAdapter;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text;
public partial class BirthMovieProbe:Node3D
{
 CombatFeedbackVisuals feedback;GameSimulation sim;GameEvent melee,ray;Camera3D cam;Node3D world;Label label;
 int frame;bool ready,finished;string output;readonly StringBuilder trace=new();readonly List<object> authority=new();
 public override void _Ready(){try{
  output=ProjectSettings.GlobalizePath("res://evidence");System.IO.Directory.CreateDirectory(output);
  if(DisplayServer.GetName()=="headless"&& !Array.Exists(OS.GetCmdlineUserArgs(),s=>s=="--preflight"))throw new Exception("Native MovieWriter requires visible renderer");
  var content=JsonSerializer.Deserialize<GameContent>(FileAccess.GetFileAsString("res://content/gameplay.json"),new JsonSerializerOptions{PropertyNameCaseInsensitive=true});
  sim=new GameSimulation(content,new SimulationLimits());var twin=new GameSimulation(content,new SimulationLimits());sim.StartRun("crit",1030);twin.StartRun("crit",1030);GameEvent? m=null,r=null;
  for(int n=0;n<900&&(!m.HasValue||!r.HasValue);n++){sim.Step();twin.Step();sim.TryGetEntity(sim.PlayerId,out var p);twin.TryGetEntity(twin.PlayerId,out var q);if(sim.Tick!=twin.Tick||p.Health!=q.Health||sim.Coins!=twin.Coins||sim.EventCount!=twin.EventCount)throw new Exception("Core parity");
   for(int i=0;i<sim.EventCount;i++){var e=sim.GetEvent(i);var t=twin.GetEvent(i);if(e.Kind!=t.Kind||e.Mechanism!=t.Mechanism||e.Value!=t.Value||!e.From.Equals(t.From)||!e.To.Equals(t.To))throw new Exception("Event parity");authority.Add(new{tick=sim.Tick,index=i,kind=e.Kind.ToString(),mechanism=e.Mechanism.ToString(),fromX=e.From.X,fromY=e.From.Y,toX=e.To.X,toY=e.To.Y,value=e.Value,hp=p.Health,coins=sim.Coins});if(e.Kind==EventKind.Melee&&e.Mechanism==FeedbackMechanism.BasicMelee&&!m.HasValue)m=e;if(e.Kind==EventKind.Ray&&e.Mechanism==FeedbackMechanism.Ricochet&&!r.HasValue)r=e;}}
  if(!m.HasValue||!r.HasValue)throw new Exception("Missing real attacks");melee=m.Value;ray=r.Value;
  System.IO.File.WriteAllText(output+"/authority-trace.json",JsonSerializer.Serialize(authority));
  world=new Node3D();AddChild(world);var center=new Vector3((melee.From.X+melee.To.X+ray.From.X+ray.To.X)/4,0,(melee.From.Y+melee.To.Y+ray.From.Y+ray.To.Y)/4);
  cam=new Camera3D{Projection=Camera3D.ProjectionType.Orthogonal,Size=16.8f,Position=center+new Vector3(12,22,18),Current=true};world.AddChild(cam);cam.LookAt(center,Vector3.Up);
  using(var mesh=new BoxMesh{Size=new Vector3(80,.3f,80)})using(var mat=new StandardMaterial3D{AlbedoColor=new Color(.89f,.81f,.67f),ShadingMode=BaseMaterial3D.ShadingModeEnum.Unshaded})world.AddChild(new MeshInstance3D{Mesh=mesh,MaterialOverride=mat,Position=new Vector3(0,-.15f,0)});
  feedback=new CombatFeedbackVisuals();AddChild(feedback);feedback.Initialize(512,cam,world);
  var canvas=new CanvasLayer();AddChild(canvas);label=new Label{Position=new Vector2(20,28),Text="CONTROLLED: real Core event replay | 4 updates/s | not a performance test"};label.AddThemeColorOverride("font_color",new Color(.12f,.08f,.15f));canvas.AddChild(label);
  trace.AppendLine("update\tdelta\tpaused\tevent\ttickFrozen\thp\tcoins\tcameraX\tcameraY\tcameraZ");ready=true;
 }catch(Exception e){GD.PushError(e.ToString());GetTree().Quit(1);}}
 public override void _Process(double delta){if(!ready||finished)return;try{
  if(frame==40){finished=true;System.IO.File.WriteAllText(output+"/render-authority.tsv",trace.ToString());GD.Print("BIRTH_MOVIE_COMPLETE updates=40 delta=.25 actualRecordedFramesCheckFfprobe=true realEventReplay=true");GetTree().Quit();return;}
  bool paused=frame>=29&&frame<=32;string cue="gap";
  // Repetition is explicit controlled replay after Reset, not new authoritative damage.
  if(frame==4||frame==12||frame==20||frame==28)feedback.Reset();
  feedback.BeginFrame(melee.RunToken,melee.Wave,paused,true);
  if(frame==4||frame==20||frame==28){if(!feedback.Consume(melee,0,melee.Tick,sim.PlayerId))throw new Exception("Melee rejected");cue="real Melee replay";}
  if(frame==12){if(!feedback.Consume(ray,0,ray.Tick,sim.PlayerId))throw new Exception("Ray rejected");cue="real Ricochet replay";}
  feedback.Advance(.25f,paused);
  label.Text=$"CONTROLLED REAL-EVENT REPLAY | 4 updates/s | not FPS measurement\n{frame+1}/40  {cue}  {(paused?"PAUSED: cosmetics frozen":"delta 0.25s; original TTL unchanged")}";
  sim.TryGetEntity(sim.PlayerId,out var p);trace.Append(frame).Append('\t').Append("0.25").Append('\t').Append(paused).Append('\t').Append(cue).Append('\t').Append(sim.Tick).Append('\t').Append(p.Health).Append('\t').Append(sim.Coins).Append('\t').Append(cam.Position.X.ToString("R")).Append('\t').Append(cam.Position.Y.ToString("R")).Append('\t').Append(cam.Position.Z.ToString("R")).AppendLine();
  GD.Print($"BIRTH_MOVIE_FRAME update={frame} active={feedback.ActiveBodyCount} paused={paused}");frame++;
 }catch(Exception e){finished=true;GD.PushError(e.ToString());GetTree().Quit(1);}}
}

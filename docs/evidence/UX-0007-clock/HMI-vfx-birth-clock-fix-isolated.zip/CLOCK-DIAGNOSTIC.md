# UX0007 newborn-cue clock counterexample — diagnosis only

The production context root was NOT modified. This small standalone project
copies exact CombatFeedbackVisuals/CombatSkillBodies and17 Core sources (see
source-parity.json), actual content and no assets/UI/audio. Build0 warnings;
actual headless process exit0,956 diagnostic assertions. No editor import or
native-pixel acceptance is claimed.

GameHost._Process currently executes BeginFrame, up to8 Core Step/Consume
cycles, RenderEntities, then feedback.Advance(elapsed), before drawing.
The equivalent controller order is exercised with unchanged real Melee and
Ricochet events collected from a normal seed1030 Core simulation. No injected
GameEvents, HP edits, damage timing or TTL changes.

## Observed state immediately before first rendering opportunity

|delta|new Melee|new Ricochet|old (age .08) both|
|---|---|---|---|
|.016|active1, alpha1|active1, alpha1|active1|
|.100|active1, alpha.576923|active1, alpha.355030|expired0|
|.250|expired0, Visible=false|expired0, Visible=false|expired0|

The two actual attacks in the first8-step catch-up window at tick8 were
accepted and active2 before final Advance(.25), then active0/hidden before
render. Control simulation HP remains100 exactly, with matching original
Core events/coins/ticks. Thus the lost-first-frame condition is real in
presentation state, not merely inferred from the gallery's long timing.
The earlier catch-up attempt reused the previous diagnostic's event cursor;
its log is retained but superseded by explicit Reset before independent Core
runs. Final catch-up active2→0 is the canonical result.

## Proposed next decision — not implemented

Do not extend attack TTL, advance damage, or replay dropped effects. Consider
an explicit per-effect newborn flag: a newly accepted effect receives one
render opportunity at age0; subsequent Advance updates use normal elapsed and
existing lifetimes. Old cues must continue expiring normally. Paused Advance
must not consume the newborn flag; clear/scope/priority replacement discards
it with the same slot. This can be a single cosmetic clock rule, with no Core,
Host timing, alpha/material, lifetime constants or attack animations changed.
Whether to apply this rule to the whole existing effect pool or only new body
attacks is an owner decision before implementation. Do not call the proposal
a fix yet. Re-run the exact red cases plus existing54 and body1009/native
storage tests after any approved change; normal-context visuals still matter.

No guarantee is made that an offscreen/minimized window actually presents a
frame; the proposed contract is a render opportunity, not a GPU/display ack.

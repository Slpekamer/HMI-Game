using Godot;
using Hmi.Core;
using Hmi.GodotAdapter;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
public partial class VfxClockProbe : Node3D
{
 Task task;bool ended;int checks;
 readonly List<object> rows=new();
 void Check(bool condition,string reason){checks++;if(!condition)throw new Exception(reason);}
 public override void _Ready(){task=Run();}
 public override void _Process(double delta)
 {
  if(ended||task==null||!task.IsCompleted)return;ended=true;
  if(task.IsFaulted){GD.PushError(task.Exception.ToString());GetTree().Quit(1);return;}
  System.IO.File.WriteAllText(ProjectSettings.GlobalizePath("res://clock-results.json"),JsonSerializer.Serialize(new{checks,cases=rows},new JsonSerializerOptions{WriteIndented=true}));
  GD.Print("CLOCK_DIAGNOSTIC_COMPLETE checks="+checks+"; birth-clock contract behavior only; no native pixel or release claim");GetTree().Quit();
 }
 async Task Run()
 {
  var content=JsonSerializer.Deserialize<GameContent>(FileAccess.GetFileAsString("res://content/gameplay.json"),new JsonSerializerOptions{PropertyNameCaseInsensitive=true});
  var sim=new GameSimulation(content,new SimulationLimits());var control=new GameSimulation(content,new SimulationLimits());sim.StartRun("crit",1030);control.StartRun("crit",1030);
  GameEvent? melee=null,ray=null;EntityId player=sim.PlayerId;
  for(int i=0;i<900&&(!melee.HasValue||!ray.HasValue);i++)
  {
   sim.Step();control.Step();Check(sim.Tick==control.Tick&&sim.EventCount==control.EventCount&&sim.Coins==control.Coins,"collect authority parity");
   sim.TryGetEntity(player,out var p);control.TryGetEntity(control.PlayerId,out var c);Check(p.Health==c.Health&&p.Position.Equals(c.Position),"collect HP position parity");
   for(int j=0;j<sim.EventCount;j++){var e=sim.GetEvent(j);if(e.Kind==EventKind.Melee&&e.Mechanism==FeedbackMechanism.BasicMelee&&!melee.HasValue)melee=e;if(e.Kind==EventKind.Ray&&e.Mechanism==FeedbackMechanism.Ricochet&&!ray.HasValue)ray=e;}
  }
  Check(melee.HasValue&&ray.HasValue,"real Core produced both event kinds without event injection");
  var world=new Node3D();AddChild(world);var camera=new Camera3D();world.AddChild(camera);var f=new CombatFeedbackVisuals();AddChild(f);f.Initialize(512,camera,world);
  foreach(var e in new[]{melee.Value,ray.Value})foreach(float delta in new[]{.016f,.1f,.25f})foreach(bool existing in new[]{false,true})
  {
   f.Reset();f.BeginFrame(e.RunToken,e.Wave,false,true);Check(f.Consume(e,0,e.Tick,player),"unchanged real event accepted");
   if(existing){f.Advance(.016f,false);f.BeginFrame(e.RunToken,e.Wave,false,true);f.Advance(.08f,false);f.BeginFrame(e.RunToken,e.Wave,false,true);}
   int before=f.ActiveBodyCount;Check(before==1,"attack body exists before final Advance");
   var material=(StandardMaterial3D)world.GetNode<MeshInstance3D>("SkillBodyA_00").MaterialOverride;
   float beforeAlpha=material.AlbedoColor.A;
   // This is the exact feedback-call order in Host _Process: BeginFrame/Consume -> final Advance(elapsed) -> draw.
   f.Advance(delta,false);
   int after=f.ActiveBodyCount;bool visible=world.GetNode<MeshInstance3D>("SkillBodyA_00").Visible;
   bool expectedExpired=existing && delta+.08f>= (e.Kind==EventKind.Melee?.16f:.13f);
   Check((after==0)==expectedExpired&&visible==!expectedExpired,"newborn gets first render opportunity while existing cue expires normally");
   rows.Add(new{kind=e.Kind.ToString(),mechanism=e.Mechanism.ToString(),sourceTick=e.Tick,delta,existingAge=existing?.08f:0,before,after,visible,beforeAlpha,afterAlpha=material.AlbedoColor.A,coreAdvancedDuringPresentation=false});
   if(!existing){f.BeginFrame(e.RunToken,e.Wave,false,true);f.Advance(.25f,false);Check(f.ActiveBodyCount==0,"birth protection lasts only one nonpaused advance");}
   GD.Print($"CLOCK_CASE kind={e.Kind} delta={delta} existing={existing} before={before} after={after} visible={visible} alpha={material.AlbedoColor.A}");
  }
  // Eight real steps in one render, matching Host's cap; all state still comes from Core.
  sim=new GameSimulation(content,new SimulationLimits());control=new GameSimulation(content,new SimulationLimits());sim.StartRun("crit",1030);control.StartRun("crit",1030);f.Reset();bool found=false;
  for(int frame=0;frame<100&&!found;frame++)
  {
   f.BeginFrame(sim.RunToken,sim.Wave,false,true);int attacks=0;
   for(int step=0;step<8;step++)
   {
    sim.Step();control.Step();f.SetState(sim.RunToken,sim.Wave,sim.Paused,sim.Phase==RunPhase.Combat);
    Check(sim.Tick==control.Tick&&sim.EventCount==control.EventCount&&sim.Coins==control.Coins,"catchup authority parity");
    for(int j=0;j<sim.EventCount;j++)
    {
     var e=sim.GetEvent(j);var c=control.GetEvent(j);Check(e.Kind==c.Kind&&e.Source==c.Source&&e.Target==c.Target&&e.Value==c.Value&&e.From.Equals(c.From)&&e.To.Equals(c.To),"catchup exact real event parity");
     f.Consume(e,j,sim.Tick,sim.PlayerId);if(e.Kind==EventKind.Melee||e.Kind==EventKind.Ray)attacks++;
    }
   }
   int before=f.ActiveBodyCount;f.Advance(.25f,false);int after=f.ActiveBodyCount;
   if(attacks>0&&before>0)
   {
    sim.TryGetEntity(sim.PlayerId,out var p);control.TryGetEntity(control.PlayerId,out var c);Check(p.Health==c.Health&&p.Position.Equals(c.Position),"catchup player HP position unchanged");
    Check(after==before,"all accepted catchup newborn bodies survive first rendering opportunity");found=true;
    rows.Add(new{caseName="real-8step-catchup",tick=sim.Tick,attacks,before,after,playerHP=p.Health,controlHP=c.Health,delta=.25f});
    GD.Print($"CLOCK_CATCHUP tick={sim.Tick} attacks={attacks} before={before} after={after} HP={p.Health}/{c.Health}");
   }
  }
  Check(found,"actual eight-step stream produced a newborn-zero-before-draw counterexample");
  // Pause must not consume protection, and scope must clear it.
  var test=ray.Value;f.Reset();f.BeginFrame(test.RunToken,test.Wave,false,true);f.Consume(test,0,test.Tick,player);
  f.Advance(.25f,true);Check(f.ActiveBodyCount==1,"pause preserves newborn");f.BeginFrame(test.RunToken,test.Wave,true,true);f.Advance(.25f,true);Check(f.ActiveBodyCount==1,"paused render generation does not age cue");f.BeginFrame(test.RunToken,test.Wave,false,true);f.Advance(.016f,false);Check(f.ActiveBodyCount==1,"resume ages only actual unpaused delta");f.BeginFrame(test.RunToken,test.Wave,false,true);f.Advance(.25f,false);Check(f.ActiveBodyCount==0,"next old opportunity expires normally");
  f.Reset();f.BeginFrame(test.RunToken,test.Wave,false,true);f.Consume(test,0,test.Tick,player);f.BeginFrame(test.RunToken+1,test.Wave,false,true);f.Advance(.25f,false);Check(f.ActiveBodyCount==0,"scope clears newborn flags with pool");
  f.Reset();f.BeginFrame(test.RunToken,test.Wave,false,true);
  using var cube=new BoxMesh();var actor=new MeshInstance3D{Mesh=cube};world.AddChild(actor);
  f.Bind(new EntityView(player,EntityKind.Player,new Vec2(0,0),new Vec2(0,-1),100,100,"test"),actor);
  var damage=new GameEvent(EventKind.Damage,new EntityId(33,1),player,new Vec2(1,0),new Vec2(0,0),7,1,test.RunToken,test.Wave,FeedbackMechanism.EnemyContact);
  f.Consume(damage,0,1,player);f.Advance(.25f,false);
  Check(actor.MaterialOverlay!=null&&f.PlayerCueActive,"newborn tint state and player cue not expired before first opportunity");f.BeginFrame(test.RunToken,test.Wave,true,true);f.Advance(.25f,true);Check(actor.MaterialOverlay!=null&&f.PlayerCueActive,"paused existing tint and player cue retained");
  f.BeginFrame(test.RunToken,test.Wave,false,true);f.Consume(new GameEvent(EventKind.Damage,new EntityId(33,1),player,new Vec2(1,0),new Vec2(0,0),7,2,test.RunToken,test.Wave,FeedbackMechanism.EnemyContact),0,2,player);f.Advance(.1f,false);
  Check(actor.MaterialOverlay!=null&&f.CoalescedHits>0,"coalesced same-target hit does not create new pulse");f.BeginFrame(test.RunToken,test.Wave,false,true);f.Advance(.25f,false);Check(actor.MaterialOverlay==null&&!f.PlayerCueActive,"existing tint/player cue really expire without merged-hit extension");
  f.Reset();f.BeginFrame(test.RunToken,test.Wave,false,true);
  var enemyId=new EntityId(7,1);f.Bind(new EntityView(enemyId,EntityKind.Enemy,new Vec2(0,0),new Vec2(0,-1),10,10,"test"),actor);
  f.Consume(new GameEvent(EventKind.Damage,player,enemyId,new Vec2(1,0),new Vec2(0,0),2,1,test.RunToken,test.Wave,FeedbackMechanism.BasicMelee),0,1,player);f.Advance(.25f,false);
  Check(actor.MaterialOverlay!=null,"newborn enemy tint retains original zero-alpha start without premature restore");
  f.BeginFrame(test.RunToken,test.Wave,false,true);f.Consume(new GameEvent(EventKind.Damage,player,enemyId,new Vec2(1,0),new Vec2(0,0),2,2,test.RunToken,test.Wave,FeedbackMechanism.BasicMelee),0,2,player);f.Advance(.1f,false);
  Check(actor.MaterialOverlay is StandardMaterial3D oldTint&&oldTint.AlbedoColor.A>0,"coalesced enemy hit continues old tint envelope rather than refreshing birth");
  f.BeginFrame(test.RunToken,test.Wave,false,true);f.Advance(.25f,false);Check(actor.MaterialOverlay==null,"merged enemy hit cannot indefinitely extend tint");
  f.Reset();f.BeginFrame(test.RunToken,test.Wave,false,true);
  for(int tick=1;tick<=8;tick++){f.SetState(test.RunToken,test.Wave,false,true);for(int j=0;j<30;j++)f.Consume(new GameEvent(EventKind.Ray,player,new EntityId(j+1,1),new Vec2(0,0),new Vec2(2,0),2,tick,test.RunToken,test.Wave,FeedbackMechanism.Ricochet),j,tick,player);}
  f.Advance(.25f,false);Check(f.ActiveBodyCount==12&&f.SpawnedThisFrame==12,"eight-step birth guards never refill12 budget");f.Advance(.25f,false);Check(f.ActiveBodyCount==12,"repeated Advance in same render cannot consume birth protection");f.BeginFrame(test.RunToken,test.Wave,false,true);f.Advance(.25f,false);Check(f.ActiveBodyCount==0,"catchup births do not become immortal");
  f.QueueFree();await ToSignal(GetTree(),SceneTree.SignalName.ProcessFrame);world.QueueFree();await ToSignal(GetTree(),SceneTree.SignalName.ProcessFrame);
 }
}
